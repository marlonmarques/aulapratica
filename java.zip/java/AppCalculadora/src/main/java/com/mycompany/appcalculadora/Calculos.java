/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.appcalculadora;

import java.math.BigDecimal;
import java.util.Scanner;

/**
 *
 * @author marlon
 */
public class Calculos {
    
    Scanner entrada = new Scanner(System.in);
    
    public void iniciar() {
        int opcao;

        do {
            exibirOpcao();
            opcao = entrada.nextInt();
            operacao(opcao);
        } while (opcao != 6);

    }
    
    public void exibirOpcao() {
        System.out.println("\t Escolha a opção desejada");
        System.out.println("1 - Soma");
        System.out.println("2 - Subtração");
        System.out.println("3 - Multiplicação");
        System.out.println("4 - Divisão");
        System.out.println("5 - Raiz quadrada");
        System.out.println("6 - Sair\n");
        System.out.print("Opção: ");
    }

    public void operacao(int opcao) {
        
        if(opcao == 5){
            System.out.println("Digite valor para raiz: ");
            int valor = entrada.nextInt();
            
            raiz(valor);
        }else{
            System.out.println("Digite o primeiro valor: ");
            BigDecimal valor1 = entrada.nextBigDecimal();

            System.out.println("Digite o segundo valor: ");
            BigDecimal valor2 = entrada.nextBigDecimal();
            
        switch (opcao) {
            case 1:

            soma(valor1, valor2);
            
                break;
            case 2:

            sutracao(valor1, valor2);

                break;
            case 3:

            multiplicacao(valor1, valor2);

                break;
            case 4:

            divisao(valor1, valor2);

                break;
            case 6:
                System.out.println("Sistema encerrado.");
                break;

            default:
                System.out.println("Opção inválida");
        }
        }
    }
    
    public void soma(BigDecimal valor1, BigDecimal valor2) {
        System.out.println("Resultado soma: " + valor1.add(valor2) + "\n");
    }
    
    public void sutracao(BigDecimal valor1, BigDecimal valor2) {
        System.out.println("Resultado subtração: " + valor1.subtract(valor2) + "\n");
    }
    
    public void multiplicacao(BigDecimal valor1, BigDecimal valor2) {
        System.out.println("Resultado multiplicação: " + valor1.multiply(valor2) + "\n");
    }
    
    public void divisao(BigDecimal valor1, BigDecimal valor2) {
        System.out.println("Resultado divisão: " + valor1.divide(valor2) + "\n");
    }
    
    public void raiz(int valor1) {
        System.out.println("Resultado raiz quadrada: " + Math.sqrt(valor1) + "\n");
    }
}
