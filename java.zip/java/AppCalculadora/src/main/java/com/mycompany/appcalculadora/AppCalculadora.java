/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.appcalculadora;
import java.util.Scanner;
/**
 *
 * @author marlon
 */
public class AppCalculadora {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        boolean continua = true;

        while (continua) {

            try {
                Calculos operacao = new Calculos();
                operacao.iniciar();
                
            } catch (Exception exception) {
                System.out.println("Exception " + exception.getMessage());
 
            } finally {
                System.out.println("Deseja continuar a operação?  \n1 - Sim `, `, poispois\n2 - Não");
                int reiniciar = scan.nextInt();
                if (reiniciar == 2) {
                    continua = false;
                    scan.close();
                }
            }
            System.out.println("Obrigado por utilizar a calculadora!");

        }
    }
}
