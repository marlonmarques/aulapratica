/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gerenciabanco2;

/**
 *
 * @author marlon
 */
public class contaBanco {

    private double saldo;

    // Construtor
    public contaBanco() {
        this.saldo = 0.0;

    }

    // Métodos
    public double consultarSaldo() {
        return saldo;

    }

    public void depositar(double valor) {
        saldo += valor;

    }

    public void realizarRetirada(double valor) {

        if (valor > 0 && valor <= saldo) {
            saldo -= valor;
        } else {
            System.out.println("Saldo insuficiente.");

        }

    }
}
