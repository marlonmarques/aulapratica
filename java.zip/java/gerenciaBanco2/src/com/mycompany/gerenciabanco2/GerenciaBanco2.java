/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.gerenciabanco2;

import java.util.Scanner;

/**
 *
 * @author marlon
 */

public class GerenciaBanco2 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite seu nome:");
        String nome = scanner.nextLine();
        System.out.println("Digite seu sobrenome:");
        String sobrenome = scanner.nextLine();
        System.out.println("Digite seu CPF:");
        String cpf = scanner.nextLine();
        Usuario usuario = new Usuario(nome, sobrenome, cpf);
        contaBanco conta = new contaBanco();
        System.out.println("Bem-vindo, " + usuario.getNome() + " " + usuario.getSobrenome() + "!");
        System.out.println("CPF: " + usuario.getCpf());
        System.out.println("Saldo inicial: R$ " + conta.consultarSaldo());

        // Operações bancárias
        conta.depositar(500.0);
        System.out.println("Novo saldo após depósito: R$ " + conta.consultarSaldo());
        conta.realizarRetirada(120.0);
        System.out.println("Novo saldo após retirada: R$ " + conta.consultarSaldo());
        
        aplicarBanco minhaConta = new aplicarBanco(usuario.getNome(), usuario.getCpf(), conta.consultarSaldo());
        minhaConta.iniciar();
        
        System.out.println("Operações concluídas. Obrigado!");
        scanner.close();

    }
}
