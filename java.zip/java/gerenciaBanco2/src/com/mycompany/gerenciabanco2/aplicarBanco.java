/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gerenciabanco2;

import java.util.Scanner;
import java.text.DecimalFormat; 

/**
 *
 * @author marlon
 */
public class aplicarBanco {

    private String nome;
    private String cpf;
    private double saldo;
    private double lci;
    private double cdb;
    private double alicota;
    Scanner entrada = new Scanner(System.in);
    DecimalFormat df = new DecimalFormat("#,###.00");

    public aplicarBanco(String nome, String cpf, double saldo) {
        this.nome = nome;
        this.cpf = cpf;
        this.saldo = saldo;
    }

    public void extrato() {
        System.out.println("\tEXTRATO");
        System.out.println("Nome: " + this.nome);
        System.out.println("Número CPF: " + this.cpf);
        System.out.printf("Saldo atual: %.2f\n", this.saldo);

    }

    public void sacar(double valor) {
        if (saldo >= valor) {
            saldo -= valor;
            System.out.println("Sacado: " + valor);
            System.out.println("Novo saldo: " + saldo + "\n");
        } else {
            System.out.println("Saldo insuficiente. Faça um depósito\n");
        }
    }

    public void depositar(double valor) {
        saldo += valor;
        System.out.println("Depositado: " + valor);
        System.out.println("Novo saldo: " + saldo + "\n");
    }

    public void cdb(double valor, int parcelas) {
        if (saldo >= valor) {
            saldo -= valor;
            alicota = (10.00 / 12) * parcelas;
            cdb = (alicota * 100 / valor) + valor;
            System.out.println("Novo saldo: " + df.format(saldo) + "\n");
            System.out.println(""+df.format(valor)+" Em: " + parcelas + " meses rende = "+ df.format(cdb) +"\n");
            System.out.println("Rendimento: " + df.format(alicota * 100 / valor) + "\n");
        } else {
            System.out.println("Saldo insuficiente. Faça um depósito\n");
        }
    }

    public void lci(double valor, int parcelas) {
        if (saldo >= valor) {
            saldo -= valor;
            alicota = (8.00 / 12) * parcelas;
            lci = (alicota * 100 / valor) + valor;
            System.out.println("Novo saldo: " + df.format(saldo) + "\n");
            System.out.println(""+df.format(valor)+" Em: " + parcelas + " meses rende = "+ df.format(lci) +"\n");
            System.out.println("Rendimento: " + df.format(alicota * 100 / valor) + "\n");
        } else {
            System.out.println("Saldo insuficiente. Faça um depósito\n");
        }
    }

    public void iniciar() {
        int opcao;

        do {
            exibeOperacao();
            opcao = entrada.nextInt();
            operacaoOpcao(opcao);
        } while (opcao != 3);

    }

    public void exibeOperacao() {

        System.out.println("\t Escolha a opção desejada");
        System.out.println("1 - Transações comuns");
        System.out.println("2 - Investimentos");
        System.out.println("3 - Sair\n");
        System.out.print("Opção: ");

    }

    public void operacaoOpcao(int opcao) {

        switch (opcao) {
            case 1:

                do {
                    exibeMenu();
                    opcao = entrada.nextInt();
                    escolheOpcao(opcao);
                } while (opcao != 4);

                break;
            case 2:

                do {
                    exibeAplicacao();
                    opcao = entrada.nextInt();
                    escolheOpcaoAplicacao(opcao);
                } while (opcao != 3);

                break;
            case 3:
                System.out.println("Sistema encerrado.");
                break;

            default:
                System.out.println("Opção inválida");
        }
    }

    public void exibeMenu() {

        System.out.println("\t Escolha a opção desejada");
        System.out.println("1 - Verificar saldo");
        System.out.println("2 - Depositar valor");
        System.out.println("3 - Retirar valor");
        System.out.println("4 - Sair\n");
        System.out.print("Opção: ");

    }

    public void escolheOpcao(int opcao) {
        double valor;

        switch (opcao) {
            case 1:
                extrato();
                break;
            case 2:
                System.out.print("Quanto deseja depositar: ");
                valor = entrada.nextDouble();
                depositar(valor);
                break;

            case 3:
                System.out.print("Quanto deseja sacar: ");
                valor = entrada.nextDouble();
                sacar(valor);
                break;

            case 4:
                System.out.println("Sistema encerrado.");
                break;

            default:
                System.out.println("Opção inválida");
        }
    }

    public void exibeAplicacao() {

        System.out.println("\t Escolha a opção desejada");
        System.out.println("1 - CDB (10% ao ano)");
        System.out.println("2 - LCI (8% ao ano)");
        System.out.println("3 - Sair\n");
        System.out.print("Opção: ");

    }

    public void escolheOpcaoAplicacao(int opcao) {
        double valor;
        int parcelas;

        switch (opcao) {
            case 1:
                System.out.print("Quanto deseja aplicar CDB: ");
                valor = entrada.nextDouble();
                System.out.print("Quantos meses: ");
                parcelas = entrada.nextInt();
                cdb(valor, parcelas);
                break;

            case 2:
                System.out.print("Quanto deseja aplicar LCI: ");
                valor = entrada.nextDouble();
                System.out.print("Quantos meses: ");
                parcelas = entrada.nextInt();
                lci(valor, parcelas);
                break;

            case 3:
                System.out.println("Sistema encerrado.");
                break;

            default:
                System.out.println("Opção inválida");
        }
    }
}
