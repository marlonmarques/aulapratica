/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.gerenciabanco;

import java.util.Scanner;

/**
 *
 * @author marlon
 */

public class GerenciaBanco {
    

    private String nome;
    private String sobrenome;
    private String cpf;
    
    private double saldo;
    
    // Métodos
    public double consultarSaldo() {
        return saldo;

    }

    public void depositar(double valor) {
        saldo += valor;

    }

    public void realizarRetirada(double valor) {

        if (valor > 0 && valor <= saldo) {
            saldo -= valor;
        } else {
            System.out.println("Saldo insuficiente.");

        }

    }

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite seu nome:");
        String nome = scanner.nextLine();
        System.out.println("Digite seu sobrenome:");
        String sobrenome = scanner.nextLine();
        System.out.println("Digite seu CPF:");
        String cpf = scanner.nextLine();

        GerenciaBanco conta = new GerenciaBanco();
        System.out.println("Bem-vindo, " + nome + " " + sobrenome + "!");
        System.out.println("CPF: " + cpf);
        System.out.println("Saldo inicial: R$ " + conta.consultarSaldo());

        // Operações bancárias
        conta.depositar(500.0);
        System.out.println("Novo saldo após depósito: R$ " + conta.consultarSaldo());
        conta.realizarRetirada(120.0);
        System.out.println("Novo saldo após retirada: R$ " + conta.consultarSaldo());
        System.out.println("Operações concluídas. Obrigado!");
        scanner.close();

    }
}
